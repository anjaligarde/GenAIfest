package com.vm.genAI.service;

import com.vm.genAI.model.Fnol;
import com.vm.genAI.repository.FnolRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class FnolService {

    private static final Logger logger = LoggerFactory.getLogger(FnolService.class);

    @Autowired
    private FnolRepository fnolRepository;

    public Fnol createFnol(Fnol fnol) {
        if (fnol == null) {
            logger.error("Attempted to create a null FNOL");
            throw new IllegalArgumentException("FNOL cannot be null");
        }
        logger.info("Created FNOL with ID: {}", fnol.getId());
        return fnolRepository.save(fnol);
    }

    public List<Fnol> getAllFnols() {
        logger.info("Fetching all FNOLs");
        return fnolRepository.findAll();
    }

    public Optional<Fnol> getFnolById(Long id) {
        if (id == null) {
            logger.error("Attempted to fetch FNOL with null ID");
            throw new IllegalArgumentException("ID cannot be null");
        }
        logger.info("Fetching FNOL with ID: {}", id);
        return fnolRepository.findById(id);
    }

    public Optional<Fnol> updateFnol(Long id, Fnol updatedFnol) {
        if (id == null || updatedFnol == null) {
            logger.error("Attempted to update FNOL with null ID or null data");
            throw new IllegalArgumentException("ID and FNOL data cannot be null");
        }
        if (fnolRepository.existsById(id)) {
            updatedFnol.setId(id);
            logger.info("Updated FNOL with ID: {}", id);
            return Optional.of(fnolRepository.save(updatedFnol));
        }
        logger.warn("FNOL with ID: {} not found for update", id);
        return Optional.empty();
    }

    public boolean deleteFnol(Long id) {
        if (id == null) {
            logger.error("Attempted to delete FNOL with null ID");
            throw new IllegalArgumentException("ID cannot be null");
        }
        if (fnolRepository.existsById(id)) {
            fnolRepository.deleteById(id);
            logger.info("Deleted FNOL with ID: {}", id);
            return true;
        }
        logger.warn("FNOL with ID: {} not found for deletion", id);
        return false;
    }
}