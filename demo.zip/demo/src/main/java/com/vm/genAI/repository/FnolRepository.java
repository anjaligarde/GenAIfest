package com.vm.genAI.repository;

import com.vm.genai.model.Fnol;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FnolRepository extends JpaRepository<Fnol, Long> {
}