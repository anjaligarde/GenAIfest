package com.vm.genAI.controller;

import com.vm.genAI.model.Fnol;
import com.vm.genAI.service.FnolService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/fnol")
public class FnolController {

    @Autowired
    private FnolService fnolService;

    // Hello World endpoint
    @GetMapping("/hello")
    public String sayHello() {
        return "Hello World";
    }

    // Create a new FNOL
    @PostMapping
    public ResponseEntity<Fnol> createFnol(@RequestBody Fnol fnol) {
        try {
            Fnol createdFnol = fnolService.createFnol(fnol);
            return new ResponseEntity<>(createdFnol, HttpStatus.CREATED);
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
        }
    }

    // Get all FNOLs
    @GetMapping
    public List<Fnol> getAllFnols() {
        return fnolService.getAllFnols();
    }

    // Get a specific FNOL by ID
    @GetMapping("/{id:[0-9]+}")
    public ResponseEntity<Fnol> getFnolById(@PathVariable Long id) {
        return fnolService.getFnolById(id)
                .map(ResponseEntity::ok)
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // Update an FNOL
    @PutMapping("/{id}")
    public ResponseEntity<Fnol> updateFnol(@PathVariable Long id, @RequestBody Fnol updatedFnol) {
        return fnolService.updateFnol(id, updatedFnol)
                .map(ResponseEntity::ok)
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // Delete an FNOL
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteFnol(@PathVariable Long id) {
        return fnolService.deleteFnol(id)
                ? new ResponseEntity<>("Deleted successfully", HttpStatus.OK)
                : new ResponseEntity<>("FNOL not found", HttpStatus.NOT_FOUND);
    }
}