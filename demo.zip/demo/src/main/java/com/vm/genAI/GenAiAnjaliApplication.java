package com.vm.genAI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GenAiAnjaliApplication {

	public static void main(String[] args) {
		SpringApplication.run(GenAiAnjaliApplication.class, args);
	}

}
