package com.vm.genAI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GenAiAnjaliApplicationTests {

	@Test
	void contextLoads() {
	}

}
